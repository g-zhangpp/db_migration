from sqlalchemy.ext import declarative

Base = declarative.declarative_base()
